import pandas as pd 
import matplotlib.pyplot as plt 
import numpy as np

arq = 'NintendoGames.csv'

dados = pd.read_csv(arq)

colunas_irrelevantes  = [col for col in dados.columns if dados[col].nunique() == 1 ]

data_limpo = dados.drop(columns=colunas_irrelevantes)

# print(data_limpo)

data_limpo['title'].fillna(data_limpo['title'].mode()[0], inplace=True)

print('Estatistica')
print(data_limpo.describe())

plt.figure(figsize=(10,5))

# pontuação máxima

plt.subplot(1,2,1)
plt.hist(data_limpo['user_score'], bins = 20, color  = 'blue', edgecolor = 'black')
plt.title( 'Pontuação máxima de jogadores' )
plt.xlabel('Usuários')
plt.ylabel('Pontução')

plt.subplot(1,2,1)
plt.hist(data_limpo['platform'], bins = 20, color  = 'blue', edgecolor = 'black')
plt.title( 'Pontuação máxima de jogadores' )
plt.xlabel('Consoles')
plt.ylabel('Pontução')

plt.tight_layout()
plt.show()
